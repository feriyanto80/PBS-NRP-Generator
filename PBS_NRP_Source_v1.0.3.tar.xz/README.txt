PBS NRP Generator v1.0.3 cumulative source
Windows portable EXE build: run build_windows.bat on Windows 10/11 x64 with Python 3.11+.
OSM roads/buildings are fetched explicitly via Overpass and cached locally. Internet needed on first fetch.
PDF + DXF generated without AutoCAD. DWG conversion needs separately installed ODA File Converter; redistribution rights not included.
This release is source + build workflow, not a prebuilt Windows EXE. UI is Tkinter, not pixel-identical mockup.
Sheet split is overview + 4 quadrants; not professional optimized automatic sheet tiling.
