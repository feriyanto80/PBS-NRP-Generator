import os, math, zipfile, tempfile, subprocess, shutil, threading, tkinter as tk, json, hashlib, urllib.request, urllib.parse
from tkinter import ttk, filedialog, messagebox
from xml.etree import ElementTree as ET
from reportlab.pdfgen import canvas as pdfcanvas
from reportlab.lib.pagesizes import A3, landscape
import ezdxf

NS={'k':'http://www.opengis.net/kml/2.2'}
COLORS={'FEEDER':'#e52328','SUBFEEDER':'#9323b7','DISTRIBUSI':'#ed269e','OTHER':'#aa8b24'}

def read_kmz(path):
    with zipfile.ZipFile(path) as z:
        name=next((n for n in z.namelist() if n.lower().endswith('.kml')),None)
        if not name: raise ValueError('Tidak ditemukan file KML dalam KMZ')
        root=ET.fromstring(z.read(name))
    lines=[]; points=[]
    for pm in root.findall('.//k:Placemark',NS):
        name=pm.findtext('k:name','',NS) or ''
        category=('FEEDER' if 'FEEDER' in name.upper() and 'SUB' not in name.upper() else 'SUBFEEDER' if 'SUB' in name.upper() else 'DISTRIBUSI')
        for el in pm.findall('.//k:LineString/k:coordinates',NS):
            xy=[]
            for item in (el.text or '').split():
                try:
                    lon,lat=map(float,item.split(',')[:2]);xy.append((lon,lat))
                except Exception: pass
            if len(xy)>1: lines.append((name,category,xy))
        for el in pm.findall('.//k:Point/k:coordinates',NS):
            try:
                lon,lat=map(float,(el.text or '').strip().split(',')[:2]);points.append((name,(lon,lat)))
            except Exception: pass
    if not lines and not points:raise ValueError('Tidak ada geometri titik/jalur yang terbaca')
    return lines,points

def fetch_osm(bb, cache_dir=None):
    """Fetch actual OSM roads and building outlines; cached per extent.
    Explicit acquisition only; no synthetic geometries.
    """
    cache_dir=cache_dir or os.path.join(os.path.expanduser('~'),'.pbs_nrp','osm_cache')
    os.makedirs(cache_dir,exist_ok=True)
    x0,y0,x1,y1=bb
    # Keep requests bounded; huge extents should be subdivided by caller.
    if (x1-x0)*(y1-y0)>0.08:
        raise ValueError('Area terlalu luas untuk satu request OSM; pilih KMZ area lebih kecil.')
    bbox=','.join(f'{v:.6f}' for v in (y0,x0,y1,x1))
    key=hashlib.sha256(bbox.encode()).hexdigest()[:20]
    cache=os.path.join(cache_dir,key+'.json')
    if os.path.exists(cache):
        with open(cache,encoding='utf8') as f:return json.load(f)
    query=f'[out:json][timeout:80];(way["highway"]({bbox});way["building"]({bbox}););out geom;'
    data=urllib.parse.urlencode({'data':query}).encode()
    req=urllib.request.Request('https://overpass.kumi.systems/api/interpreter',data=data,headers={'User-Agent':'PBS-NRP-Generator/1.0 (+local desktop engineering tool)'})
    with urllib.request.urlopen(req,timeout=100) as response:payload=json.load(response)
    result={'roads':[],'buildings':[],'source':'OpenStreetMap via Overpass API','bbox':bbox}
    for element in payload.get('elements',[]):
        geom=[(pt['lon'],pt['lat']) for pt in element.get('geometry',[]) if 'lon' in pt and 'lat' in pt]
        if len(geom)<2:continue
        tags=element.get('tags',{})
        if 'highway' in tags:result['roads'].append(geom)
        if 'building' in tags:result['buildings'].append(geom)
    with open(cache,'w',encoding='utf8') as f:json.dump(result,f)
    return result

def draw_osm_pdf(c,osm,xy):
    if not osm:return
    for category,gray,width in [('buildings',.77,.32),('roads',.57,.75)]:
        c.setStrokeColorRGB(gray,gray,gray);c.setLineWidth(width)
        for pts in osm.get(category,[]):
            p=c.beginPath()
            for i,pt in enumerate(pts):
                x,y=xy(pt)
                if i:p.lineTo(x,y)
                else:p.moveTo(x,y)
            c.drawPath(p)

def bounds(lines,points):
    xy=[p for _,_,pts in lines for p in pts]+[p for _,p in points]
    xs=[p[0] for p in xy];ys=[p[1] for p in xy]
    return min(xs),min(ys),max(xs),max(ys)

def sheets_for(b):
    x0,y0,x1,y1=b;dx=x1-x0;dy=y1-y0
    # Overview + 4 quadrants; common coordinates on every sheet
    return [('Overview',b),('Detail Barat Laut',(x0,y0+dy*.5,x0+dx*.5,y1)),('Detail Timur Laut',(x0+dx*.5,y0+dy*.5,x1,y1)),('Detail Barat Daya',(x0,y0,x0+dx*.5,y0+dy*.5)),('Detail Tenggara',(x0+dx*.5,y0,x1,y0+dy*.5))]

def viewport(bb,w,h,pad):
    x0,y0,x1,y1=bb
    lat=math.radians((y0+y1)/2)
    factor=max(.01,math.cos(lat));dx=max((x1-x0)*factor,1e-8);dy=max(y1-y0,1e-8)
    scale=min((w-2*pad)/dx,(h-2*pad)/dy)
    def project(p):return (w/2+(p[0]-(x0+x1)/2)*factor*scale,h/2+(p[1]-(y0+y1)/2)*scale)
    return project

def draw_pdf(path,lines,points,project, page_w,page_h, title, sheet,osm=None):
    c=pdfcanvas.Canvas(path,pagesize=(page_w,page_h))
    for i,(sname,bb) in enumerate(sheet):
        c.setStrokeColorRGB(.16,.16,.16);c.setLineWidth(.8);c.rect(13,13,page_w-26,page_h-26)
        c.setLineWidth(.35);c.rect(19,19,page_w-38,page_h-38)
        c.setFont('Helvetica-Bold',10);c.drawString(30,page_h-37,f'{title} | {sname}')
        c.setFont('Helvetica',7);c.drawRightString(page_w-30,29,f'SHEET {i+1}/5 | WGS84 KML source | NOT SURVEY-CERTIFIED')
        tr=viewport(bb,page_w-60,page_h-100,18)
        def xy(p):
            x,y=tr(p);return x+30,y+47
        c.saveState();p=c.beginPath();p.rect(22,43,page_w-44,page_h-91);c.clipPath(p,stroke=0)
        draw_osm_pdf(c,osm,xy)
        for name,cat,pts in lines:
            col=COLORS[cat];c.setStrokeColor(col);c.setLineWidth(1.0 if cat=='FEEDER' else .5)
            pathobj=c.beginPath()
            for j,pt in enumerate(pts):
                x,y=xy(pt)
                if j==0:pathobj.moveTo(x,y)
                else:pathobj.lineTo(x,y)
            c.drawPath(pathobj)
        c.setFont('Helvetica',4.3)
        for name,pt in points:
            x,y=xy(pt)
            c.setFillColorRGB(.95,.75,.08);c.setStrokeColorRGB(.15,.15,.15);c.circle(x,y,1.9,stroke=1,fill=1)
            if name and (i>0):
                c.setFillColorRGB(.1,.1,.1);c.drawString(x+2,y+2,name[:22])
        c.restoreState();c.showPage()
    c.save()

def draw_dxf(path,lines,points,all_sheets,osm=None):
    doc=ezdxf.new('R2010');m=doc.modelspace()
    for cat,col in [('FEEDER',1),('SUBFEEDER',200),('DISTRIBUSI',6)]:doc.layers.new(cat,dxfattribs={'color':col})
    doc.layers.new('POINTS',dxfattribs={'color':2});doc.layers.new('LABELS',dxfattribs={'color':7})
    doc.layers.new('FRAME',dxfattribs={'color':7})
    doc.layers.new('OSM_ROADS',dxfattribs={'color':8})
    doc.layers.new('OSM_BUILDINGS',dxfattribs={'color':9})
    # CAD model space is local projected meters (Web Mercator), not a survey CRS.
    R=6378137
    def metric(p):return (R*math.radians(p[0]),R*math.log(math.tan(math.pi/4+math.radians(max(-85,min(85,p[1])))/2)))
    if osm:
        for category,layer in [('roads','OSM_ROADS'),('buildings','OSM_BUILDINGS')]:
            for pts in osm.get(category,[]):m.add_lwpolyline([metric(p) for p in pts],dxfattribs={'layer':layer})
    for name,cat,pts in lines:m.add_lwpolyline([metric(p) for p in pts],dxfattribs={'layer':cat})
    for name,p in points:
        x,y=metric(p);m.add_circle((x,y),1.3,dxfattribs={'layer':'POINTS'})
        if name:m.add_text(name[:64],dxfattribs={'height':1.5,'insert':(x+1.5,y+1.5),'layer':'LABELS'})
    doc.header['$INSUNITS']=6
    doc.saveas(path)

def convert_dwg(dxf_path,converter):
    if not converter or not os.path.isfile(converter):raise RuntimeError('ODA File Converter belum dipilih. DWG memerlukan converter berlisensi terpisah.')
    with tempfile.TemporaryDirectory() as inp,tempfile.TemporaryDirectory() as out:
        shutil.copy2(dxf_path,inp)
        # ODA File Converter CLI: input output version type recursive audit
        p=subprocess.run([converter,inp,out,'ACAD2018','DWG','0','1'],capture_output=True,text=True,timeout=180)
        result=os.path.join(out,os.path.splitext(os.path.basename(dxf_path))[0]+'.dwg')
        if p.returncode!=0 or not os.path.exists(result):raise RuntimeError('Konversi DWG gagal: '+(p.stderr or p.stdout)[-400:])
        shutil.copy2(result,os.path.splitext(dxf_path)[0]+'.dwg')

class App:
    def __init__(self,root):
        self.root=root;root.title('PBS Network Route Plan Generator v1.0.3');root.geometry('1450x860');root.configure(bg='#eef2f6')
        self.path=tk.StringVar();self.converter=tk.StringVar();self.status=tk.StringVar(value='Pilih KMZ untuk memulai');self.lines=[];self.points=[];self.osm=None;self.use_osm=tk.BooleanVar(value=True)
        top=tk.Frame(root,bg='#134b84',height=58);top.pack(fill='x');tk.Label(top,text='PBS  Network Route Plan Generator   v1.0.3',fg='white',bg='#134b84',font=('Segoe UI',17,'bold')).pack(side='left',padx=18,pady=12)
        steps=tk.Frame(root,bg='white');steps.pack(fill='x',pady=3)
        for t in ['1  Import KMZ','2  Basemap & Area','3  Pemetaan & Simbol','4  Layout & Sheet','5  Export']:
            tk.Label(steps,text=t,bg='#e5f0fb',fg='#15395c',font=('Segoe UI',10,'bold'),padx=15,pady=12).pack(side='left',expand=True,fill='x',padx=3)
        body=tk.PanedWindow(root,orient='horizontal',sashwidth=5,bg='#d7e2ed');body.pack(fill='both',expand=True,padx=7,pady=5)
        left=tk.Frame(body,bg='white',width=310);body.add(left,minsize=280)
        self.section(left,'1. Import KMZ');tk.Button(left,text='Pilih file KMZ...',command=self.open_kmz).pack(fill='x',padx=12,pady=6)
        tk.Label(left,textvariable=self.path,wraplength=275,bg='white',fg='#52616c').pack(padx=12)
        self.stats=tk.Label(left,text='Belum ada data',justify='left',bg='white',font=('Consolas',10));self.stats.pack(anchor='w',padx=16,pady=12)
        self.section(left,'2. Basemap & Area');tk.Checkbutton(left,text='Aktifkan OSM jalan + bangunan',variable=self.use_osm,bg='white').pack(anchor='w',padx=12)
        tk.Button(left,text='Ambil / gunakan cache OSM',command=self.load_osm).pack(fill='x',padx=12,pady=5)
        self.section(left,'3. Pemetaan & Simbol');tk.Label(left,text='Feeder merah · Subfeeder ungu\nDistribusi magenta · Titik kuning',justify='left',bg='white').pack(padx=12,pady=9)
        self.section(left,'4. Layout & Sheet');tk.Label(left,text='A3 Landscape · Double-Line Frame\nOverview + 4 detail quadrants',justify='left',bg='white').pack(padx=12,pady=9)
        self.section(left,'5. Export');tk.Button(left,text='Pilih ODA File Converter (opsional)',command=self.pick_oda).pack(fill='x',padx=12,pady=6)
        self.want_dwg=tk.BooleanVar()
        tk.Checkbutton(left,text='Konversi juga ke DWG (butuh ODA)',variable=self.want_dwg,bg='white').pack(anchor='w',padx=12)
        tk.Button(left,text='▶  Generate PDF + DXF (+ DWG)',bg='#17813e',fg='white',font=('Segoe UI',11,'bold'),command=self.export).pack(fill='x',padx=12,pady=12)
        center=tk.Frame(body,bg='white');body.add(center,minsize=400)
        tk.Label(center,text='Map Preview — geometri KMZ',bg='white',font=('Segoe UI',11,'bold')).pack(anchor='w',padx=10,pady=7)
        self.map=tk.Canvas(center,bg='#fafafa',highlightthickness=0);self.map.pack(fill='both',expand=True)
        self.map.bind('<Configure>',lambda e:self.draw())
        right=tk.Frame(body,bg='white',width=300);body.add(right,minsize=250)
        tk.Label(right,text='Preview Sheet',bg='white',font=('Segoe UI',12,'bold')).pack(anchor='w',padx=12,pady=9)
        self.sheet=ttk.Combobox(right,values=['1 - Overview','2 - Barat Laut','3 - Timur Laut','4 - Barat Daya','5 - Tenggara'],state='readonly');self.sheet.current(0);self.sheet.pack(fill='x',padx=12);self.sheet.bind('<<ComboboxSelected>>',lambda e:self.draw())
        self.mini=tk.Canvas(right,bg='white',height=245);self.mini.pack(fill='x',padx=10,pady=14);self.mini.bind('<Configure>',lambda e:self.draw())
        self.section(right,'Legenda');
        for name,col in [('FEEDER','#e52328'),('SUBFEEDER','#9323b7'),('DISTRIBUSI','#ed269e'),('POINT','#e5b800')]:
            rr=tk.Frame(right,bg='white');rr.pack(anchor='w',padx=18,pady=8);tk.Label(rr,text='━━━━',fg=col,bg='white',font=('Segoe UI',13,'bold')).pack(side='left');tk.Label(rr,text=name,bg='white').pack(side='left',padx=10)
        tk.Label(root,textvariable=self.status,bg='#e7edf5',anchor='w',padx=10).pack(fill='x')
    def section(self,parent,title):tk.Label(parent,text=title,bg='#e7edf5',fg='#173957',anchor='w',font=('Segoe UI',10,'bold'),padx=10,pady=8).pack(fill='x',pady=(8,0))
    def open_kmz(self):
        p=filedialog.askopenfilename(filetypes=[('Google Earth KMZ','*.kmz')]);
        if not p:return
        try:self.lines,self.points=read_kmz(p);self.path.set(p);self.stats.config(text=f'Jalur (LineString)  {len(self.lines):,}\nTitik (Point)       {len(self.points):,}\nTotal geometri     {len(self.lines)+len(self.points):,}');self.status.set('KMZ berhasil dibaca');self.draw()
        except Exception as e:messagebox.showerror('Import gagal',str(e))
    def load_osm(self):
        if not self.lines and not self.points:
            messagebox.showwarning('OSM','Import KMZ terlebih dahulu');return
        self.status.set('Mengambil data OSM, mohon tunggu...')
        def worker():
            try:
                osm=fetch_osm(bounds(self.lines,self.points))
                self.root.after(0,lambda:self.osm_ready(osm))
            except Exception as e:
                self.root.after(0,lambda msg=str(e):self.status.set('OSM gagal: '+msg))
        threading.Thread(target=worker,daemon=True).start()
    def osm_ready(self,osm):
        self.osm=osm;self.status.set(f"OSM: {len(osm['roads'])} jalan, {len(osm['buildings'])} bangunan (cache aktif)");self.draw()
    def pick_oda(self):
        p=filedialog.askopenfilename(filetypes=[('Executable','*.exe')]);
        if p:self.converter.set(p)
    def draw_on(self,canvas,bb):
        canvas.delete('all');w=max(canvas.winfo_width(),200);h=max(canvas.winfo_height(),200)
        if not self.lines and not self.points:canvas.create_text(w/2,h/2,text='Import KMZ untuk melihat jaringan',fill='#667788');return
        tr=viewport(bb,w,h,18)
        if self.osm and self.use_osm.get():
            for kind,color in [('buildings','#c8c8c8'),('roads','#a8a8a8')]:
                for pts in self.osm.get(kind,[]):
                    xy=[]
                    for p in pts:
                        x,y=tr(p);xy.extend((x,h-y))
                    if len(xy)>=4:canvas.create_line(*xy,fill=color,width=1)
        for name,cat,pts in self.lines:
            xy=[]
            for p in pts:xy.extend(tr(p))
            if len(xy)>=4:canvas.create_line(*[v if j%2==0 else h-v for j,v in enumerate(xy)],fill=COLORS[cat],width=2 if cat=='FEEDER' else 1)
        if canvas is self.map:
            for name,p in self.points:
                x,y=tr(p);y=h-y
                if -5<x<w+5 and -5<y<h+5:canvas.create_oval(x-2,y-2,x+2,y+2,fill='#ffcf32',outline='#333')
        canvas.create_rectangle(4,4,w-4,h-4,outline='#555');canvas.create_rectangle(8,8,w-8,h-8,outline='#aaa')
    def draw(self):
        if not self.lines and not self.points:return
        b=bounds(self.lines,self.points);self.draw_on(self.map,b)
        idx=self.sheet.current();self.draw_on(self.mini,sheets_for(b)[max(0,idx)][1])
    def export(self):
        if not self.lines and not self.points:messagebox.showwarning('Data belum ada','Import KMZ terlebih dahulu');return
        folder=filedialog.askdirectory(title='Pilih folder output')
        if not folder:return
        try:
            title=os.path.splitext(os.path.basename(self.path.get()))[0];safe='PBS_NRP_'+''.join(c if c.isalnum() else '_' for c in title)[:65]
            pdf=os.path.join(folder,safe+'.pdf');dxf=os.path.join(folder,safe+'.dxf');sheets=sheets_for(bounds(self.lines,self.points))
            draw_pdf(pdf,self.lines,self.points,None,*landscape(A3),title,sheets,self.osm if self.use_osm.get() else None)
            draw_dxf(dxf,self.lines,self.points,sheets,self.osm if self.use_osm.get() else None)
            result='PDF dan DXF berhasil dibuat.'
            if self.want_dwg.get():
                try:convert_dwg(dxf,self.converter.get());result+=' DWG berhasil dibuat.'
                except Exception as e:result+='\nDWG tidak dibuat: '+str(e)
            self.status.set(result);messagebox.showinfo('Hasil export',result+'\n\n'+folder)
        except Exception as e:messagebox.showerror('Export gagal',str(e))
if __name__=='__main__':
    root=tk.Tk();App(root);root.mainloop()
